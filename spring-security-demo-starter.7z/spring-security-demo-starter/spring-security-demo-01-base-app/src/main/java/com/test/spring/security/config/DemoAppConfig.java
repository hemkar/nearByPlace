package com.test.spring.security.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages={"com.test.spring.security"})
public class DemoAppConfig {
	
	@Bean
	public ViewResolver resolver(){
		
		InternalResourceViewResolver viewReslover= new InternalResourceViewResolver();
		viewReslover.setPrefix("/WEB-INF/VIEW/");
		viewReslover.setSuffix(".jsp");
		return viewReslover;
		
	} 

}
